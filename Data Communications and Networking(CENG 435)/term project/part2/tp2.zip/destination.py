import hashlib # used for generating md5 Checksums
import socket # for python Socket API
import struct  # used in decoding and encoding messages
import threading # used for multithreaded structure
import time  # used to generate timestamps

if __name__ == "__main__":

	#create and array of <index,data>

	#create sockets for listening to routers

	#create sockets for receiving packets from routers
	#decode the packet
	
	#create md5 checksums for packet
	#check the created md5 with received md5 
		#if equal, save the packet, send <index,ACK> to router
		#else, send <index, NACK> to router
	
	#if we receive last correct packet close all sockets