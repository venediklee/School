import hashlib # used for generating md5 Checksums
import socket  # for python Socket API
import struct # used in encoding and decoding messages
import threading # multithreaded structure
import time # used for timeout calculations

if __name__ == "__main__":

	#create and array of <index,bool received by destination,data>

	

	#create sockets for listening to source
	#start listening to source for packets

	#create md5 checksums for packet
	#check the created md5 with received md5 
		#if equal, save the packet, send <index,ACK> to source, alert sender thread with <index>
		#else, send <index, NACK> to source

	######## in sender thread #########
	#do the same things you did in source but target to destination

	#if all packets are ticked close all sockets

	TODO: shutdown problem