import hashlib # used for generating md5 Checksums
import socket # for python Socket API
import struct  # used in encoding messages
import time  # used to generate timestamps
import threading # used for multithreaded structure

if __name__ == "__main__":

	#create sockets for listening to routers
	#start listening to routers for packet received messages

	#create sockets for sending packets to routers
	#pack the file
	
	#create md5 checksums for each packet
	#create and array of <index,bool:received by router,md5,data>

	#decide on which files to send to which link
	#start encoding->sending files to routers

	##if router sends received information(<index,ACK>) tick the array[index]
	##if router sends received information(<index,NACK>) resend on same link
	##if router timeouts, resend on same link
	##if router sends last received information of its responsible array;
		# start sending the other links' unticked packets in the finished link

	#if all packets are ticked close all sockets