public class HardTire extends Tire {

  public HardTire() {
    this.speed = 275;
    this.degradation = 0;
  }
}
