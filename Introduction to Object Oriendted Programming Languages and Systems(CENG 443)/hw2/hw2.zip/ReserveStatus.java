public enum ReserveStatus
{
	Unknown,
	Reserved,
	NotReserved
}
