Every folder contains an input, output and src folder. The input folder contains
the input that will be provided to your solution. The output is the resulting
outputs for Map model and MapReduce model. The file output_mr.txt is the output for
the MapReduce Model and the file output_m.txt is the output for the Map model.
The src folder contains the source codes for the mapper and reducer for the 
task. After compiling the mapper and reducer using make, you can give the path
of the mapper and reducer executables as arguments to your program.

In the example provided, the tasks were run on 2 mappers and reducers.

